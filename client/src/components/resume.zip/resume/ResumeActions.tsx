import { motion } from "framer-motion";
import {
  Download,
  RotateCcw,
  Share2,
  Trash2,
  Sparkles,
} from "lucide-react";

import { Button } from "../ui/button";

interface ResumeActionsProps {
  file: File;
  onReplace?: () => void;
  onDelete?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
  onAnalyzeAgain?: () => void;
}

export default function ResumeActions({
  file,
  onReplace,
  onDelete,
  onDownload,
  onShare,
  onAnalyzeAgain,
}: ResumeActionsProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.35,
      }}
      className="rounded-3xl border bg-white p-8 shadow-sm"
    >
      <div className="mb-8">
        <h2 className="text-2xl font-bold">
          Resume Actions
        </h2>

        <p className="mt-2 text-sm text-muted-foreground">
          Manage your uploaded resume or continue improving it.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        <ActionCard
          icon={<Download className="h-5 w-5" />}
          title="Download Resume"
          description="Download the uploaded resume."
          button="Download"
          onClick={
            onDownload ??
            (() => {
              const url = URL.createObjectURL(file);

              const link = document.createElement("a");
              link.href = url;
              link.download = file.name;
              link.click();

              URL.revokeObjectURL(url);
            })
          }
        />

        <ActionCard
          icon={<RotateCcw className="h-5 w-5" />}
          title="Replace Resume"
          description="Upload an updated version."
          button="Replace"
          onClick={onReplace}
        />

        <ActionCard
          icon={<Sparkles className="h-5 w-5" />}
          title="Analyze Again"
          description="Run ATS analysis once more."
          button="Analyze"
          onClick={onAnalyzeAgain}
        />

        <ActionCard
          icon={<Share2 className="h-5 w-5" />}
          title="Share Report"
          description="Share your analysis with others."
          button="Share"
          onClick={onShare}
        />

        <ActionCard
          icon={<Trash2 className="h-5 w-5" />}
          title="Delete Resume"
          description="Remove this resume permanently."
          button="Delete"
          destructive
          onClick={onDelete}
        />
      </div>
    </motion.section>
  );
}

interface ActionCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  button: string;
  destructive?: boolean;
  onClick?: () => void;
}

function ActionCard({
  icon,
  title,
  description,
  button,
  destructive,
  onClick,
}: ActionCardProps) {
  return (
    <motion.div
      whileHover={{
        y: -5,
      }}
      className="rounded-2xl border bg-slate-50 p-6 transition-all hover:shadow-lg"
    >
      <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
        {icon}
      </div>

      <h3 className="text-lg font-semibold">
        {title}
      </h3>

      <p className="mt-2 text-sm text-muted-foreground">
        {description}
      </p>

      <Button
        className="mt-6 w-full"
        variant={destructive ? "destructive" : "default"}
        onClick={onClick}
      >
        {button}
      </Button>
    </motion.div>
  );
}