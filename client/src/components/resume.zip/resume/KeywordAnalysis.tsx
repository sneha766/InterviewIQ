import { motion } from "framer-motion";
import { Search, XCircle } from "lucide-react";

interface KeywordAnalysisProps {
  missingKeywords: string[];
}

export default function KeywordAnalysis({
  missingKeywords,
}: KeywordAnalysisProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: 0.1 }}
      className="rounded-3xl border bg-white p-8 shadow-sm"
    >
      <div className="mb-8 flex items-center gap-3">
        <div className="rounded-xl bg-blue-100 p-3">
          <Search className="h-6 w-6 text-blue-600" />
        </div>

        <div>
          <h2 className="text-xl font-bold">
            Missing ATS Keywords
          </h2>

          <p className="text-sm text-muted-foreground">
            These keywords commonly appear in job descriptions
            but were not found in your resume.
          </p>
        </div>
      </div>

      {missingKeywords.length === 0 ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
            <Search className="h-8 w-8 text-emerald-600" />
          </div>

          <h3 className="text-lg font-semibold text-emerald-700">
            Excellent!
          </h3>

          <p className="mt-2 text-sm text-emerald-600">
            No important ATS keywords are missing.
            Your resume is well optimized.
          </p>
        </div>
      ) : (
        <>
          <div className="flex flex-wrap gap-3">
            {missingKeywords.map((keyword, index) => (
              <motion.div
                key={keyword}
                initial={{
                  opacity: 0,
                  scale: 0.8,
                }}
                animate={{
                  opacity: 1,
                  scale: 1,
                }}
                transition={{
                  delay: index * 0.05,
                }}
                whileHover={{
                  scale: 1.05,
                }}
                className="flex items-center gap-2 rounded-full border border-red-200 bg-red-50 px-4 py-2"
              >
                <XCircle className="h-4 w-4 text-red-500" />

                <span className="text-sm font-medium text-red-700">
                  {keyword}
                </span>
              </motion.div>
            ))}
          </div>

          <div className="mt-8 rounded-2xl border bg-slate-50 p-5">
            <h4 className="font-semibold">
              Why are keywords important?
            </h4>

            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Applicant Tracking Systems compare your resume
              against the job description. Including relevant
              technical skills, tools, and technologies improves
              the likelihood that your resume reaches a recruiter.
            </p>
          </div>
        </>
      )}
    </motion.section>
  );
}