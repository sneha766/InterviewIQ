import ResumeUpload from "../components/resume/ResumeUpload";

export default function Resume(){

    return(

        <div className="space-y-8">

            <div>

                <h1 className="text-3xl font-bold">
                    Resume Manager
                </h1>

                <p className="text-slate-500 mt-2">
                    Upload your resume and analyze it using AI.
                </p>

            </div>

            <ResumeUpload/>

        </div>

    );

}