import { motion } from "framer-motion";
import { BrainCircuit } from "lucide-react";

import ATSScoreCard from "./ATSScoreCard";
import KeywordAnalysis from "./KeywordAnalysis";
import Suggestions from "./Suggestions";
import ResumeActions from "./ResumeActions";

import type { ResumeAnalysis } from "../../types/resume";

interface AnalysisResultProps {
  file: File;
  analysis: ResumeAnalysis;
  onReplace?: () => void;
  onDelete?: () => void;
  onAnalyzeAgain?: () => void;
}

export default function AnalysisResult({
  file,
  analysis,
  onReplace,
  onDelete,
  onAnalyzeAgain,
}: AnalysisResultProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      <div className="rounded-3xl border bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 p-8 text-white shadow-sm">
        <div className="flex items-center gap-4">
          <div className="rounded-2xl bg-white/15 p-4 backdrop-blur">
            <BrainCircuit className="h-8 w-8" />
          </div>

          <div>
            <h1 className="text-3xl font-bold">
              Resume Analysis Complete
            </h1>

            <p className="mt-2 text-blue-100">
              Your resume has been evaluated using our ATS engine.
              Review your score, missing keywords and AI recommendations
              below.
            </p>
          </div>
        </div>
      </div>

      <ATSScoreCard
        score={analysis.score}
        strengths={analysis.strengths}
      />

      <KeywordAnalysis
        missingKeywords={analysis.missingKeywords}
      />

      <Suggestions
        suggestions={analysis.suggestions}
      />

      <ResumeActions
        file={file}
        onReplace={onReplace}
        onDelete={onDelete}
        onAnalyzeAgain={onAnalyzeAgain}
      />
    </motion.div>
  );
}