import { motion } from "framer-motion";
import {
  Lightbulb,
  ArrowUpRight,
  Sparkles,
  CheckCircle2,
} from "lucide-react";

interface SuggestionsProps {
  suggestions: string[];
}

export default function Suggestions({
  suggestions,
}: SuggestionsProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.35,
        delay: 0.15,
      }}
      className="rounded-3xl border bg-white p-8 shadow-sm"
    >
      <div className="mb-8 flex items-center gap-3">
        <div className="rounded-xl bg-amber-100 p-3">
          <Lightbulb className="h-6 w-6 text-amber-600" />
        </div>

        <div>
          <h2 className="text-xl font-bold">
            AI Resume Suggestions
          </h2>

          <p className="text-sm text-muted-foreground">
            Personalized recommendations to improve your ATS score
            and increase recruiter visibility.
          </p>
        </div>
      </div>

      {suggestions.length === 0 ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-8 text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100">
            <CheckCircle2 className="h-8 w-8 text-emerald-600" />
          </div>

          <h3 className="text-lg font-semibold text-emerald-700">
            Excellent Resume
          </h3>

          <p className="mt-2 text-sm text-emerald-600">
            No improvement suggestions at the moment.
            Your resume already follows most ATS best practices.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={suggestion}
              initial={{
                opacity: 0,
                y: 20,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                delay: index * 0.08,
              }}
              whileHover={{
                y: -2,
              }}
              className="rounded-2xl border bg-slate-50 p-5 transition-shadow hover:shadow-md"
            >
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-blue-100 p-3">
                  <Sparkles className="h-5 w-5 text-blue-600" />
                </div>

                <div className="flex-1">
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="font-semibold">
                      Recommendation {index + 1}
                    </h3>

                    <span className="rounded-full bg-blue-100 px-3 py-1 text-xs font-medium text-blue-700">
                      Suggested
                    </span>
                  </div>

                  <p className="leading-7 text-slate-600">
                    {suggestion}
                  </p>

                  <div className="mt-4 flex items-center gap-2 text-sm font-medium text-blue-600">
                    <ArrowUpRight className="h-4 w-4" />

                    <span>
                      Improves ATS compatibility
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <div className="mt-8 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="rounded-full bg-white/20 p-3">
            <Sparkles className="h-6 w-6" />
          </div>

          <div>
            <h3 className="text-lg font-semibold">
              AI Recommendation
            </h3>

            <p className="mt-2 text-sm leading-6 text-blue-100">
              Apply these improvements before submitting your
              resume. Even a few targeted changes can significantly
              improve ATS ranking and increase your chances of
              reaching the interview stage.
            </p>
          </div>
        </div>
      </div>
    </motion.section>
  );
}