import { motion } from "framer-motion";
import { Award, CheckCircle2, TrendingUp } from "lucide-react";

interface ATSScoreCardProps {
  score: number;
  strengths: string[];
}

export default function ATSScoreCard({
  score,
  strengths,
}: ATSScoreCardProps) {
  const circumference = 2 * Math.PI * 52;
  const offset = circumference - (score / 100) * circumference;

  const scoreColor =
    score >= 85
      ? "text-emerald-600"
      : score >= 70
      ? "text-yellow-500"
      : "text-red-500";

  const scoreLabel =
    score >= 85
      ? "Excellent"
      : score >= 70
      ? "Good"
      : "Needs Improvement";

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="rounded-3xl border bg-white p-8 shadow-sm"
    >
      <div className="flex flex-col gap-10 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-col items-center lg:flex-row lg:gap-8">
          <div className="relative flex h-44 w-44 items-center justify-center">
            <svg
              className="-rotate-90 h-44 w-44"
              viewBox="0 0 120 120"
            >
              <circle
                cx="60"
                cy="60"
                r="52"
                strokeWidth="10"
                className="fill-none stroke-slate-200"
              />

              <motion.circle
                cx="60"
                cy="60"
                r="52"
                strokeWidth="10"
                strokeLinecap="round"
                className="fill-none stroke-blue-600"
                strokeDasharray={circumference}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset: offset }}
                transition={{
                  duration: 1.2,
                  ease: "easeOut",
                }}
              />
            </svg>

            <div className="absolute text-center">
              <p className={`text-5xl font-bold ${scoreColor}`}>
                {score}
              </p>

              <p className="text-sm text-muted-foreground">
                ATS Score
              </p>
            </div>
          </div>

          <div className="mt-6 lg:mt-0">
            <div className="flex items-center gap-2">
              <Award className="h-6 w-6 text-blue-600" />

              <h2 className="text-2xl font-bold">
                Resume Analysis
              </h2>
            </div>

            <p className="mt-3 max-w-md text-muted-foreground">
              Your resume has been analyzed using our ATS
              evaluation engine. Continue improving your
              profile to maximize interview opportunities.
            </p>

            <div className="mt-5 flex flex-wrap gap-3">
              <span className="rounded-full bg-blue-100 px-4 py-2 text-sm font-medium text-blue-700">
                ATS Friendly
              </span>

              <span className="rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700">
                {scoreLabel}
              </span>
            </div>
          </div>
        </div>

        <div className="w-full max-w-md">
          <div className="mb-6 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />

            <h3 className="text-lg font-semibold">
              Resume Strengths
            </h3>
          </div>

          <div className="space-y-4">
            {strengths.map((strength, index) => (
              <motion.div
                key={strength}
                initial={{ opacity: 0, x: 25 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  delay: index * 0.08,
                }}
                className="flex items-start gap-3 rounded-2xl border bg-slate-50 p-4"
              >
                <div className="mt-0.5 rounded-full bg-emerald-100 p-1.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                </div>

                <p className="text-sm font-medium text-slate-700">
                  {strength}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.section>
  );
}