export interface ResumeAnalysis {

    score:number;

    strengths:string[];

    missingKeywords:string[];

    suggestions:string[];

}