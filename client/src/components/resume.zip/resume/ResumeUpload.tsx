import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  FileText,
  Trash2,
  Loader2,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "../ui/button";

import ATSScoreCard from "./ATSScoreCard";
import KeywordAnalysis from "./KeywordAnalysis";
import Suggestions from "./Suggestions";
import ResumeActions from "./ResumeActions";

import { analyzeResume } from "../../services/resume.service";

import type { ResumeAnalysis } from "../../types/resume";

export default function ResumeUpload() {
  const inputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);

  const [analyzing, setAnalyzing] = useState(false);
  const [dragging, setDragging] = useState(false);

  const browseFiles = () => {
    inputRef.current?.click();
  };

  const validateFile = (selected: File) => {
    if (selected.type !== "application/pdf") {
      toast.error("Please upload a PDF resume.");
      return false;
    }

    const maxSize = 5 * 1024 * 1024;

    if (selected.size > maxSize) {
      toast.error("Resume must be smaller than 5MB.");
      return false;
    }

    return true;
  };

  const handleFile = (selected: File) => {
    if (!validateFile(selected)) return;

    setFile(selected);
    setAnalysis(null);

    toast.success("Resume uploaded successfully.");
  };

  const onInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];

    if (selected) {
      handleFile(selected);
    }
  };

  const removeResume = () => {
    setFile(null);
    setAnalysis(null);

    if (inputRef.current) {
      inputRef.current.value = "";
    }

    toast.success("Resume removed.");
  };

  const analyze = async () => {
    if (!file) {
      toast.error("Please upload your resume first.");
      return;
    }

    try {
      setAnalyzing(true);

      const result = await analyzeResume();

      setAnalysis(result);

      toast.success("Resume analyzed successfully.");
    } catch {
      toast.error("Unable to analyze resume.");
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8">
      <motion.div layout className="rounded-3xl border bg-white p-8 shadow-sm">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Resume Analyzer</h2>

          <p className="mt-2 text-sm text-muted-foreground">
            Upload your latest resume and receive an AI-powered ATS score,
            keyword analysis, and personalized suggestions.
          </p>
        </div>

        <input
          ref={inputRef}
          hidden
          type="file"
          accept=".pdf"
          onChange={onInputChange}
        />

        <motion.div
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.995 }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);

            const dropped = e.dataTransfer.files[0];

            if (dropped) {
              handleFile(dropped);
            }
          }}
          className={`rounded-3xl border-2 border-dashed p-10 transition-all duration-300 ${
            dragging
              ? "border-blue-500 bg-blue-50"
              : "border-slate-300 hover:border-blue-400 hover:bg-slate-50"
          }`}
        >
          <div className="flex flex-col items-center gap-4">
            <div className="rounded-full bg-blue-100 p-5">
              <Upload className="h-8 w-8 text-blue-600" />
            </div>

            <div className="space-y-2 text-center">
              <h3 className="text-lg font-semibold">Drag & Drop Resume</h3>

              <p className="text-sm text-muted-foreground">
                PDF files up to 5MB
              </p>
            </div>

            <Button onClick={browseFiles} className="rounded-xl">
              Browse Resume
            </Button>
          </div>
        </motion.div>
        <AnimatePresence>
          {file && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="mt-8 rounded-2xl border bg-slate-50 p-5"
            >
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-4">
                  <div className="rounded-xl bg-blue-100 p-3">
                    <FileText className="h-6 w-6 text-blue-600" />
                  </div>

                  <div>
                    <h4 className="font-semibold">{file.name}</h4>

                    <p className="text-sm text-muted-foreground">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="rounded-xl"
                    onClick={removeResume}
                    disabled={analyzing}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </Button>

                  <Button
                    className="rounded-xl"
                    onClick={analyze}
                    disabled={analyzing}
                  >
                    {analyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="mr-2 h-4 w-4" />
                        Analyze Resume
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {analyzing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-3xl border bg-white p-10 shadow-sm"
        >
          <div className="flex flex-col items-center gap-5">
            <Loader2 className="h-12 w-12 animate-spin text-blue-600" />

            <div className="space-y-2 text-center">
              <h3 className="text-xl font-semibold">
                AI is analyzing your resume...
              </h3>

              <p className="text-sm text-muted-foreground">
                Checking ATS compatibility, keyword relevance, formatting,
                readability and recruiter friendliness.
              </p>
            </div>

            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
              <motion.div
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{
                  repeat: Infinity,
                  duration: 1.4,
                  ease: "linear",
                }}
                className="h-full w-1/3 rounded-full bg-blue-600"
              />
            </div>
          </div>
        </motion.div>
      )}

      {!file && !analyzing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-3xl border bg-white p-14 shadow-sm"
        >
          <div className="flex flex-col items-center text-center">
            <div className="rounded-full bg-green-100 p-5">
              <CheckCircle2 className="h-10 w-10 text-green-600" />
            </div>

            <h3 className="mt-6 text-2xl font-semibold">
              Ready to improve your resume?
            </h3>

            <p className="mt-3 max-w-xl text-muted-foreground">
              Upload your latest resume to receive an AI-powered ATS score,
              missing keyword detection, formatting feedback, recruiter
              insights, and personalized improvement recommendations.
            </p>
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {analysis && (
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.3,
            }}
            className="space-y-8"
          >
            <ATSScoreCard
              score={analysis.score}
              strengths={analysis.strengths}
            />

            <KeywordAnalysis missingKeywords={analysis.missingKeywords} />

            <Suggestions suggestions={analysis.suggestions} />

            {analysis && file && (
              <ResumeActions
                file={file}
                onDelete={removeResume}
                onAnalyzeAgain={analyze}
                onReplace={browseFiles}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
