import { motion } from "framer-motion";
import {
  Calendar,
  Download,
  Eye,
  FileText,
  HardDrive,
} from "lucide-react";

interface ResumePreviewProps {
  file: File;
}

export default function ResumePreview({
  file,
}: ResumePreviewProps) {
  const previewUrl = URL.createObjectURL(file);

  const fileSize = (file.size / 1024 / 1024).toFixed(2);

  const uploadDate = new Date().toLocaleDateString();

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border bg-white p-8 shadow-sm"
    >
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            Resume Preview
          </h2>

          <p className="mt-2 text-sm text-muted-foreground">
            Review your uploaded resume before running the ATS
            analysis.
          </p>
        </div>

        <div className="rounded-xl bg-blue-100 p-3">
          <Eye className="h-6 w-6 text-blue-600" />
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[320px,1fr]">
        <div className="space-y-5">

          <div className="rounded-2xl border bg-slate-50 p-5">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-blue-100 p-3">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>

              <div>
                <h3 className="font-semibold break-all">
                  {file.name}
                </h3>

                <p className="text-sm text-muted-foreground">
                  PDF Resume
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border p-5">
            <div className="flex items-center gap-3">
              <HardDrive className="h-5 w-5 text-slate-500" />

              <span className="text-sm text-muted-foreground">
                Size
              </span>
            </div>

            <p className="mt-2 text-lg font-semibold">
              {fileSize} MB
            </p>
          </div>

          <div className="rounded-2xl border p-5">
            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-slate-500" />

              <span className="text-sm text-muted-foreground">
                Uploaded
              </span>
            </div>

            <p className="mt-2 text-lg font-semibold">
              {uploadDate}
            </p>
          </div>

          <a
            href={previewUrl}
            download={file.name}
            className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-3 font-medium text-white transition hover:bg-blue-700"
          >
            <Download className="h-4 w-4" />

            Download Resume
          </a>
        </div>

        <div className="overflow-hidden rounded-2xl border bg-slate-100">
          <iframe
            src={previewUrl}
            title="Resume Preview"
            className="h-[700px] w-full"
          />
        </div>
      </div>
    </motion.section>
  );
}